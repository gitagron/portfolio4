-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 13, 2021 at 10:01 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfoliodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `projects1`
--

DROP TABLE IF EXISTS `projects1`;
CREATE TABLE IF NOT EXISTS `projects1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `review` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects1`
--

INSERT INTO `projects1` (`id`, `name`, `type`, `image`, `review`) VALUES
(1, 'Federata e Paqes Universale', 'Wordpress', 'C:wamp64/www/portfolio/images/upf-mockup.jpg', 'This is just some text'),
(2, 'Uralink', 'Wordpress', 'C:wamp64/www/portfolio/images/uralink-mockup.jpg', 'This is another text'),
(3, 'Switch', 'Logo', 'C:wamp64/www/portfolio/images/switch-logo.jpg', 'This is a logo design project.'),
(4, 'Lion & Lamb Photography', 'Logo', 'C:wamp64/www/portfolio/images/l-l-p.jpg', 'This is another logo design project');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
